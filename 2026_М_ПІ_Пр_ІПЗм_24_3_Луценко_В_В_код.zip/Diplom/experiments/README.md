# Experimental scripts

## Method comparison

`compare_anomaly_methods.py` compares four anomaly detection approaches on the same
simulated telemetry dataset:

- Z-score
- Local Outlier Factor
- Isolation Forest
- Hybrid method

Run from the project root:

```powershell
python experiments\compare_anomaly_methods.py --records 1000 --threshold 0.60
```

The script prints a Markdown-like comparison table and saves CSV output to:

```text
artifacts/method_comparison.csv
```

The generated values can be used in diploma table 4.5.

