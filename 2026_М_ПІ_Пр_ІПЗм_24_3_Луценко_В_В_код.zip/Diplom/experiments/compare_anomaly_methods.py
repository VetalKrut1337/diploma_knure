from __future__ import annotations

import argparse
import csv
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

import numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.metrics import f1_score, precision_score, recall_score
from sklearn.neighbors import LocalOutlierFactor


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from anomaly_detection.infrastructure.simulator import PipelineTelemetrySimulator, SimulatorConfig
from anomaly_detection.ml.features import TelemetryFeatureBuilder


@dataclass(frozen=True)
class MethodResult:
    method: str
    precision: float
    recall: float
    f1_score: float
    fpr: float
    predicted_anomalies: int
    real_anomalies: int


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Compare Z-score, LOF, Isolation Forest and Hybrid anomaly detection methods."
    )
    parser.add_argument("--records", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--threshold", type=float, default=0.60)
    parser.add_argument("--z-threshold", type=float, default=3.0)
    parser.add_argument("--lof-contamination", type=float, default=0.10)
    parser.add_argument("--if-contamination", type=float, default=0.01)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("artifacts/method_comparison.csv"),
    )
    return parser.parse_args()


def generate_documents(records_count: int, seed: int) -> list[dict]:
    simulator = PipelineTelemetrySimulator(
        SimulatorConfig(
            anomaly_probability=0.04,
            random_state=seed,
        )
    )
    return [record.to_document() for record in simulator.generate(records_count=records_count)]


def split_normal_features(documents: list[dict]) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    normal_documents = [document for document in documents if not document["is_anomaly"]]
    if len(normal_documents) < 50:
        raise RuntimeError("Not enough normal records for method comparison.")

    feature_builder = TelemetryFeatureBuilder()
    normal_features = feature_builder.fit_transform(normal_documents)
    all_features = feature_builder.transform(documents)
    y_true = np.array([bool(document["is_anomaly"]) for document in documents], dtype=bool)
    return normal_features, all_features, y_true


def predict_z_score(normal_features: np.ndarray, all_features: np.ndarray, threshold: float) -> np.ndarray:
    center = np.mean(normal_features, axis=0)
    scale = np.std(normal_features, axis=0)
    scale = np.where(scale < 1e-8, 1.0, scale)
    z_scores = np.abs((all_features - center) / scale)
    max_z_score = np.max(z_scores, axis=1)
    return max_z_score > threshold


def predict_lof(
    normal_features: np.ndarray,
    all_features: np.ndarray,
    contamination: float,
) -> np.ndarray:
    model = LocalOutlierFactor(
        n_neighbors=20,
        contamination=contamination,
        novelty=True,
    )
    model.fit(normal_features)
    return model.predict(all_features) == -1


def predict_isolation_forest(
    normal_features: np.ndarray,
    all_features: np.ndarray,
    contamination: float,
    threshold: float,
) -> np.ndarray:
    model = IsolationForest(
        n_estimators=100,
        contamination=contamination,
        random_state=42,
    )
    model.fit(normal_features)

    train_raw_scores = -model.score_samples(normal_features)
    raw_scores = -model.score_samples(all_features)
    score_min = float(np.min(train_raw_scores))
    score_max = float(np.max(train_raw_scores))
    denominator = max(score_max - score_min, 1e-8)
    normalized_scores = np.clip((raw_scores - score_min) / denominator, 0.0, 1.0)
    return normalized_scores > threshold


def predict_hybrid(
    normal_features: np.ndarray,
    all_features: np.ndarray,
    documents: list[dict],
    if_contamination: float,
    if_threshold: float,
    z_threshold: float,
) -> np.ndarray:
    if_predictions = predict_isolation_forest(
        normal_features=normal_features,
        all_features=all_features,
        contamination=if_contamination,
        threshold=if_threshold,
    )
    z_predictions = predict_z_score(
        normal_features=normal_features,
        all_features=all_features,
        threshold=z_threshold,
    )
    rule_predictions = np.array([matches_domain_rules(document) for document in documents], dtype=bool)
    return if_predictions | (z_predictions & rule_predictions)


def matches_domain_rules(document: dict) -> bool:
    metrics = document["metrics"]
    input_rows = max(float(metrics["inputRowsPerSecond"]), 1e-8)
    processed_rows = float(metrics["processedRowsPerSecond"])
    eta = processed_rows / input_rows
    lag_ratio = float(metrics["avgOffsetsBehindLatest"]) / input_rows
    return bool(
        eta < 0.75
        or lag_ratio > 0.45
        or float(metrics["cpu_usage"]) > 88.0
        or float(metrics["batchDuration"]) > 1700.0
    )


def evaluate_predictions(method: str, y_true: np.ndarray, y_pred: np.ndarray) -> MethodResult:
    false_positive = int(np.sum((~y_true) & y_pred))
    true_negative = int(np.sum((~y_true) & (~y_pred)))
    denominator = false_positive + true_negative
    fpr = false_positive / denominator if denominator else 0.0

    return MethodResult(
        method=method,
        precision=float(precision_score(y_true, y_pred, zero_division=0)),
        recall=float(recall_score(y_true, y_pred, zero_division=0)),
        f1_score=float(f1_score(y_true, y_pred, zero_division=0)),
        fpr=float(fpr),
        predicted_anomalies=int(np.sum(y_pred)),
        real_anomalies=int(np.sum(y_true)),
    )


def save_results(results: list[MethodResult], output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(
            [
                "method",
                "precision",
                "recall",
                "f1_score",
                "fpr",
                "predicted_anomalies",
                "real_anomalies",
            ]
        )
        for result in results:
            writer.writerow(
                [
                    result.method,
                    f"{result.precision:.3f}",
                    f"{result.recall:.3f}",
                    f"{result.f1_score:.3f}",
                    f"{result.fpr:.3f}",
                    result.predicted_anomalies,
                    result.real_anomalies,
                ]
            )


def print_results(results: list[MethodResult], output_path: Path) -> None:
    headers = ["Method", "Precision", "Recall", "F1-score", "FPR", "Predicted", "Real"]
    print(" | ".join(headers))
    print(" | ".join(["---"] * len(headers)))
    for result in results:
        print(
            " | ".join(
                [
                    result.method,
                    f"{result.precision:.3f}",
                    f"{result.recall:.3f}",
                    f"{result.f1_score:.3f}",
                    f"{result.fpr:.3f}",
                    str(result.predicted_anomalies),
                    str(result.real_anomalies),
                ]
            )
        )
    print(f"\nSaved comparison table to: {output_path.resolve()}")


def main() -> None:
    args = parse_args()
    documents = generate_documents(records_count=args.records, seed=args.seed)
    normal_features, all_features, y_true = split_normal_features(documents)

    method_predictors: list[tuple[str, Callable[[], np.ndarray]]] = [
        (
            "Z-score",
            lambda: predict_z_score(
                normal_features=normal_features,
                all_features=all_features,
                threshold=args.z_threshold,
            ),
        ),
        (
            "LOF",
            lambda: predict_lof(
                normal_features=normal_features,
                all_features=all_features,
                contamination=args.lof_contamination,
            ),
        ),
        (
            "Isolation Forest",
            lambda: predict_isolation_forest(
                normal_features=normal_features,
                all_features=all_features,
                contamination=args.if_contamination,
                threshold=args.threshold,
            ),
        ),
        (
            "Hybrid",
            lambda: predict_hybrid(
                normal_features=normal_features,
                all_features=all_features,
                documents=documents,
                if_contamination=args.if_contamination,
                if_threshold=args.threshold,
                z_threshold=args.z_threshold,
            ),
        ),
    ]

    results = [
        evaluate_predictions(method=method, y_true=y_true, y_pred=predict())
        for method, predict in method_predictors
    ]
    save_results(results=results, output_path=args.output)
    print_results(results=results, output_path=args.output)


if __name__ == "__main__":
    main()

