from __future__ import annotations

from pathlib import Path
from typing import Sequence

import matplotlib.pyplot as plt

from anomaly_detection.domain.telemetry import METRIC_COLUMNS


class TelemetryVisualizer:
    def plot(
        self,
        documents: Sequence[dict],
        output_path: str | Path = "artifacts/anomaly_detection.png",
        threshold: float = 0.6,
    ) -> Path:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        x = [document["sequence_id"] for document in documents]
        true_x = [document["sequence_id"] for document in documents if document["is_anomaly"]]
        predicted_x = [
            document["sequence_id"]
            for document in documents
            if document.get("predicted_anomaly", False)
        ]

        fig, axes = plt.subplots(4, 2, figsize=(16, 14), sharex=True)
        metric_axes = axes.flatten()[:6]

        for axis, metric_name in zip(metric_axes, METRIC_COLUMNS):
            values = [document["metrics"][metric_name] for document in documents]
            axis.plot(x, values, color="#2563eb", linewidth=1.2)

            if true_x:
                true_y = [
                    document["metrics"][metric_name]
                    for document in documents
                    if document["is_anomaly"]
                ]
                axis.scatter(
                    true_x,
                    true_y,
                    facecolors="none",
                    edgecolors="#f59e0b",
                    s=42,
                    label="real anomaly",
                )

            if predicted_x:
                predicted_y = [
                    document["metrics"][metric_name]
                    for document in documents
                    if document.get("predicted_anomaly", False)
                ]
                axis.scatter(
                    predicted_x,
                    predicted_y,
                    color="#dc2626",
                    s=18,
                    label="predicted anomaly",
                )

            axis.set_title(metric_name)
            axis.grid(alpha=0.25)

        score_axis = axes.flatten()[6]
        scores = [document.get("anomaly_score", 0.0) for document in documents]
        score_axis.plot(x, scores, color="#111827", linewidth=1.2)
        score_axis.axhline(threshold, color="#dc2626", linestyle="--", linewidth=1.0)
        score_axis.set_title("anomaly score")
        score_axis.set_ylim(0.0, 1.05)
        score_axis.grid(alpha=0.25)

        summary_axis = axes.flatten()[7]
        summary_axis.axis("off")
        summary_axis.text(
            0.02,
            0.85,
            (
                f"records: {len(documents)}\n"
                f"real anomalies: {sum(document['is_anomaly'] for document in documents)}\n"
                f"predicted anomalies: {sum(document.get('predicted_anomaly', False) for document in documents)}"
            ),
            fontsize=12,
            va="top",
        )

        handles, labels = metric_axes[0].get_legend_handles_labels()
        if handles:
            fig.legend(handles, labels, loc="upper center", ncol=2)

        fig.suptitle("Telemetry anomaly detection in streaming data pipeline", fontsize=16)
        fig.tight_layout(rect=(0, 0, 1, 0.96))
        fig.savefig(output_path, dpi=150)
        plt.close(fig)

        return output_path

