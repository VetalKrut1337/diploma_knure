"""Presentation layer for reports and visual artifacts."""

