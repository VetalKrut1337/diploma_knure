from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Dict, List, Protocol, Sequence


MetricDict = Dict[str, float]

METRIC_COLUMNS: List[str] = [
    "inputRowsPerSecond",
    "processedRowsPerSecond",
    "avgOffsetsBehindLatest",
    "batchDuration",
    "cpu_usage",
    "memory_usage",
]


@dataclass(frozen=True)
class TelemetryRecord:
    sequence_id: int
    timestamp: datetime
    metrics: MetricDict
    is_anomaly: bool
    anomaly_score: float | None = None
    predicted_anomaly: bool | None = None

    def to_document(self) -> dict:
        document = {
            "timestamp": self.timestamp,
            "sequence_id": self.sequence_id,
            "metrics": self.metrics,
            "is_anomaly": self.is_anomaly,
        }
        if self.anomaly_score is not None:
            document["anomaly_score"] = self.anomaly_score
        if self.predicted_anomaly is not None:
            document["predicted_anomaly"] = self.predicted_anomaly
        return document


@dataclass(frozen=True)
class DetectionResult:
    records_count: int
    real_anomalies: int
    predicted_anomalies: int
    precision: float
    recall: float
    f1_score: float
    model_path: str
    plot_path: str


class TelemetryRepository(Protocol):
    def clear(self) -> None:
        ...

    def insert_many(self, records: Sequence[TelemetryRecord]) -> None:
        ...

    def fetch_all(self) -> List[dict]:
        ...

    def fetch_normal(self) -> List[dict]:
        ...

    def update_prediction(self, document_id, score: float, predicted_anomaly: bool) -> None:
        ...

