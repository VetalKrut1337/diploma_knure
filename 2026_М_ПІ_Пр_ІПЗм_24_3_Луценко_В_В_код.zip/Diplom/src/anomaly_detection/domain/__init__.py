"""Domain objects and contracts for telemetry anomaly detection."""

