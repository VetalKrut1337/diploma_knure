from __future__ import annotations

import argparse
from pathlib import Path

from anomaly_detection.settings import ApplicationConfig, MongoSettings, PipelineSettings


class CliConfigParser:
    def parse(self) -> ApplicationConfig:
        parser = argparse.ArgumentParser(
            description="Streaming telemetry anomaly detection prototype."
        )
        parser.add_argument("--records", type=int, default=1000)
        parser.add_argument("--threshold", type=float, default=0.6)
        parser.add_argument("--mongo-uri", type=str, default="mongodb://localhost:27017/")
        parser.add_argument("--database", type=str, default="streaming_anomaly_detection")
        parser.add_argument("--collection", type=str, default="telemetry")
        parser.add_argument(
            "--model-path",
            type=Path,
            default=Path("artifacts/isolation_forest_model.joblib"),
        )
        parser.add_argument(
            "--plot-path",
            type=Path,
            default=Path("artifacts/anomaly_detection.png"),
        )
        parser.add_argument("--seed", type=int, default=42)
        args = parser.parse_args()

        return ApplicationConfig(
            mongo=MongoSettings(
                uri=args.mongo_uri,
                database=args.database,
                collection=args.collection,
            ),
            pipeline=PipelineSettings(
                records_count=args.records,
                anomaly_threshold=args.threshold,
                model_path=args.model_path,
                plot_path=args.plot_path,
                random_state=args.seed,
            ),
        )
