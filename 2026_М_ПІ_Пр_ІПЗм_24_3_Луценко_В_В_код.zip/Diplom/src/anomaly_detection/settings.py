from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class MongoSettings:
    uri: str = "mongodb://localhost:27017/"
    database: str = "streaming_anomaly_detection"
    collection: str = "telemetry"


@dataclass(frozen=True)
class PipelineSettings:
    records_count: int = 1000
    anomaly_threshold: float = 0.6
    model_path: Path = Path("artifacts/isolation_forest_model.joblib")
    plot_path: Path = Path("artifacts/anomaly_detection.png")
    random_state: int = 42


@dataclass(frozen=True)
class ApplicationConfig:
    mongo: MongoSettings
    pipeline: PipelineSettings

