from __future__ import annotations

from typing import List, Sequence

from pymongo import ASCENDING, MongoClient
from pymongo.collection import Collection
from pymongo.errors import ServerSelectionTimeoutError

from anomaly_detection.domain.telemetry import TelemetryRecord


class MongoTelemetryRepository:
    def __init__(
        self,
        uri: str = "mongodb://localhost:27017/",
        database: str = "streaming_anomaly_detection",
        collection: str = "telemetry",
    ) -> None:
        self.client = MongoClient(uri, serverSelectionTimeoutMS=3000)
        self.database = self.client[database]
        self.collection: Collection = self.database[collection]
        self._ensure_connection()
        self.collection.create_index([("timestamp", ASCENDING)])

    def _ensure_connection(self) -> None:
        try:
            self.client.admin.command("ping")
        except ServerSelectionTimeoutError as exc:
            raise RuntimeError(
                "MongoDB is not available. Start MongoDB and check the connection URI."
            ) from exc

    def clear(self) -> None:
        self.collection.delete_many({})

    def insert_many(self, records: Sequence[TelemetryRecord]) -> None:
        documents = [record.to_document() for record in records]
        if documents:
            self.collection.insert_many(documents)

    def fetch_all(self) -> List[dict]:
        return list(self.collection.find({}).sort("timestamp", ASCENDING))

    def fetch_normal(self) -> List[dict]:
        return list(self.collection.find({"is_anomaly": False}).sort("timestamp", ASCENDING))

    def update_prediction(self, document_id, score: float, predicted_anomaly: bool) -> None:
        self.collection.update_one(
            {"_id": document_id},
            {
                "$set": {
                    "anomaly_score": float(score),
                    "predicted_anomaly": bool(predicted_anomaly),
                }
            },
        )

