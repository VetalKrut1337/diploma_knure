from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Iterator, Optional

import numpy as np

from anomaly_detection.domain.telemetry import MetricDict, TelemetryRecord


@dataclass(frozen=True)
class SimulatorConfig:
    baseline_input_rows_per_second: float = 5000.0
    baseline_batch_duration: float = 800.0
    baseline_cpu_usage: float = 45.0
    baseline_memory_usage: float = 58.0
    anomaly_probability: float = 0.04
    min_anomaly_duration: int = 5
    max_anomaly_duration: int = 18
    random_state: Optional[int] = 42


class PipelineTelemetrySimulator:
    def __init__(self, config: SimulatorConfig | None = None) -> None:
        self.config = config or SimulatorConfig()
        self.rng = np.random.default_rng(self.config.random_state)
        self.lag = 100.0

    def generate(self, records_count: int, inject_anomalies: bool = True) -> Iterator[TelemetryRecord]:
        active_anomaly: str | None = None
        anomaly_left = 0

        for sequence_id in range(records_count):
            if inject_anomalies and anomaly_left <= 0:
                active_anomaly, anomaly_left = self._next_anomaly_state()

            metrics = self._normal_metrics()
            is_anomaly = bool(active_anomaly and anomaly_left > 0)

            if is_anomaly:
                self._inject_anomaly(metrics, active_anomaly)
                anomaly_left -= 1

            self._update_dependencies(metrics, active_anomaly if is_anomaly else None)
            yield TelemetryRecord(
                sequence_id=sequence_id,
                timestamp=datetime.now(timezone.utc),
                metrics=metrics,
                is_anomaly=is_anomaly,
            )

    def _next_anomaly_state(self) -> tuple[str | None, int]:
        if self.rng.random() >= self.config.anomaly_probability:
            return None, 0

        anomaly_type = str(
            self.rng.choice(
                [
                    "spike_lag",
                    "processed_drop",
                    "cpu_growth",
                    "batch_duration_growth",
                ]
            )
        )
        duration = int(
            self.rng.integers(
                self.config.min_anomaly_duration,
                self.config.max_anomaly_duration + 1,
            )
        )
        return anomaly_type, duration

    def _normal_metrics(self) -> MetricDict:
        cfg = self.config
        input_rows = max(300.0, self.rng.normal(cfg.baseline_input_rows_per_second, 330.0))
        processed_rows = max(100.0, input_rows * self.rng.normal(0.99, 0.035))
        cpu_usage = np.clip(self.rng.normal(cfg.baseline_cpu_usage, 5.5), 1.0, 100.0)
        memory_usage = np.clip(self.rng.normal(cfg.baseline_memory_usage, 4.0), 1.0, 100.0)

        load_ratio = input_rows / cfg.baseline_input_rows_per_second
        batch_duration = cfg.baseline_batch_duration * (0.75 + 0.25 * load_ratio)
        batch_duration += self.rng.normal(0.0, 55.0)

        return {
            "inputRowsPerSecond": float(input_rows),
            "processedRowsPerSecond": float(processed_rows),
            "avgOffsetsBehindLatest": float(max(self.lag, 0.0)),
            "batchDuration": float(max(batch_duration, 100.0)),
            "cpu_usage": float(cpu_usage),
            "memory_usage": float(memory_usage),
        }

    def _inject_anomaly(self, metrics: MetricDict, anomaly_type: str) -> None:
        if anomaly_type == "spike_lag":
            metrics["avgOffsetsBehindLatest"] += float(self.rng.uniform(1200.0, 3500.0))
            metrics["batchDuration"] *= float(self.rng.uniform(1.15, 1.55))
        elif anomaly_type == "processed_drop":
            metrics["processedRowsPerSecond"] *= float(self.rng.uniform(0.35, 0.65))
            metrics["cpu_usage"] += float(self.rng.uniform(5.0, 18.0))
        elif anomaly_type == "cpu_growth":
            metrics["cpu_usage"] = float(self.rng.uniform(88.0, 99.0))
            metrics["batchDuration"] *= float(self.rng.uniform(1.25, 2.0))
        elif anomaly_type == "batch_duration_growth":
            metrics["batchDuration"] *= float(self.rng.uniform(2.0, 3.8))
            metrics["processedRowsPerSecond"] *= float(self.rng.uniform(0.70, 0.90))

    def _update_dependencies(self, metrics: MetricDict, anomaly_type: str | None) -> None:
        input_rows = metrics["inputRowsPerSecond"]
        processed_rows = metrics["processedRowsPerSecond"]
        throughput_gap = input_rows - processed_rows

        if throughput_gap > 0:
            self.lag += throughput_gap * 0.08
        else:
            self.lag += throughput_gap * 0.16

        if anomaly_type == "spike_lag":
            self.lag += float(self.rng.uniform(500.0, 1200.0))

        self.lag += float(self.rng.normal(0.0, 18.0))
        self.lag *= 0.985
        self.lag = max(self.lag, 0.0)

        metrics["avgOffsetsBehindLatest"] = float(max(metrics["avgOffsetsBehindLatest"], self.lag))

        cpu_pressure = max(0.0, metrics["cpu_usage"] - self.config.baseline_cpu_usage)
        metrics["batchDuration"] += cpu_pressure * 8.5

        if metrics["processedRowsPerSecond"] < input_rows:
            metrics["avgOffsetsBehindLatest"] += (input_rows - metrics["processedRowsPerSecond"]) * 0.10

        metrics["processedRowsPerSecond"] = float(max(metrics["processedRowsPerSecond"], 1.0))
        metrics["avgOffsetsBehindLatest"] = float(max(metrics["avgOffsetsBehindLatest"], 0.0))
        metrics["batchDuration"] = float(max(metrics["batchDuration"], 1.0))
        metrics["cpu_usage"] = float(np.clip(metrics["cpu_usage"], 1.0, 100.0))
        metrics["memory_usage"] = float(np.clip(metrics["memory_usage"], 1.0, 100.0))

