from __future__ import annotations

from anomaly_detection.application.pipeline import (
    AnomalyDetectionPipeline,
    TelemetryCollectionService,
)
from anomaly_detection.infrastructure.mongodb import MongoTelemetryRepository
from anomaly_detection.infrastructure.simulator import PipelineTelemetrySimulator, SimulatorConfig
from anomaly_detection.ml.detector import AnomalyDetector
from anomaly_detection.ml.evaluator import Evaluator
from anomaly_detection.ml.trainer import ModelTrainer
from anomaly_detection.presentation.visualizer import TelemetryVisualizer
from anomaly_detection.settings import ApplicationConfig


class ApplicationContainer:
    def __init__(self, config: ApplicationConfig) -> None:
        self.config = config

    def build_pipeline(self) -> AnomalyDetectionPipeline:
        repository = MongoTelemetryRepository(
            uri=self.config.mongo.uri,
            database=self.config.mongo.database,
            collection=self.config.mongo.collection,
        )
        simulator = PipelineTelemetrySimulator(
            SimulatorConfig(random_state=self.config.pipeline.random_state)
        )
        collector = TelemetryCollectionService(
            simulator=simulator,
            repository=repository,
        )

        return AnomalyDetectionPipeline(
            repository=repository,
            collector=collector,
            trainer=ModelTrainer(
                repository=repository,
                model_path=self.config.pipeline.model_path,
            ),
            detector=AnomalyDetector(
                repository=repository,
                threshold=self.config.pipeline.anomaly_threshold,
            ),
            evaluator=Evaluator(),
            visualizer=TelemetryVisualizer(),
            settings=self.config.pipeline,
        )
