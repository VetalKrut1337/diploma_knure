from __future__ import annotations


from anomaly_detection.domain.telemetry import DetectionResult, TelemetryRepository
from anomaly_detection.infrastructure.simulator import PipelineTelemetrySimulator
from anomaly_detection.ml.detector import AnomalyDetector
from anomaly_detection.ml.evaluator import Evaluator
from anomaly_detection.ml.trainer import ModelTrainer
from anomaly_detection.presentation.visualizer import TelemetryVisualizer
from anomaly_detection.settings import PipelineSettings


class TelemetryCollectionService:
    def __init__(
        self,
        simulator: PipelineTelemetrySimulator,
        repository: TelemetryRepository,
    ) -> None:
        self.simulator = simulator
        self.repository = repository

    def collect(self, records_count: int, clear_before: bool = True) -> None:
        if clear_before:
            self.repository.clear()

        records = list(self.simulator.generate(records_count=records_count))
        self.repository.insert_many(records)


class AnomalyDetectionPipeline:
    def __init__(
        self,
        repository: TelemetryRepository,
        collector: TelemetryCollectionService,
        trainer: ModelTrainer,
        detector: AnomalyDetector,
        evaluator: Evaluator,
        visualizer: TelemetryVisualizer,
        settings: PipelineSettings,
    ) -> None:
        self.repository = repository
        self.collector = collector
        self.trainer = trainer
        self.detector = detector
        self.evaluator = evaluator
        self.visualizer = visualizer
        self.settings = settings

    def run(self) -> DetectionResult:
        self.collector.collect(records_count=self.settings.records_count, clear_before=True)
        model_path = self.trainer.train()
        documents = self.detector.detect(model_path=model_path)
        evaluation = self.evaluator.evaluate(documents)
        plot_path = self.visualizer.plot(
            documents=documents,
            output_path=self.settings.plot_path,
            threshold=self.settings.anomaly_threshold,
        )

        return DetectionResult(
            records_count=len(documents),
            real_anomalies=sum(bool(document["is_anomaly"]) for document in documents),
            predicted_anomalies=sum(
                bool(document.get("predicted_anomaly", False)) for document in documents
            ),
            precision=evaluation.precision,
            recall=evaluation.recall,
            f1_score=evaluation.f1_score,
            model_path=str(model_path.resolve()),
            plot_path=str(plot_path.resolve()),
        )
