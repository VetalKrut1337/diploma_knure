"""Application services that coordinate the anomaly detection workflow."""

