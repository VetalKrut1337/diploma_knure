"""Telemetry anomaly detection package."""

