from __future__ import annotations

from pathlib import Path
from typing import List

import joblib
import numpy as np

from anomaly_detection.domain.telemetry import TelemetryRepository


class AnomalyDetector:
    def __init__(
        self,
        repository: TelemetryRepository,
        threshold: float = 0.6,
    ) -> None:
        self.repository = repository
        self.threshold = threshold

    def detect(self, model_path: str | Path) -> List[dict]:
        documents = self.repository.fetch_all()
        if not documents:
            return []

        artifact = joblib.load(Path(model_path))
        feature_builder = artifact["feature_builder"]
        model = artifact["model"]
        features = feature_builder.transform(documents)

        raw_scores = -model.score_samples(features)
        scores = self._normalize_scores(raw_scores, artifact)

        detected_documents = []
        for document, score in zip(documents, scores):
            predicted_anomaly = bool(score > self.threshold)
            self.repository.update_prediction(
                document_id=document["_id"],
                score=float(score),
                predicted_anomaly=predicted_anomaly,
            )
            document["anomaly_score"] = float(score)
            document["predicted_anomaly"] = predicted_anomaly
            detected_documents.append(document)

        return detected_documents

    def _normalize_scores(self, raw_scores: np.ndarray, artifact: dict) -> np.ndarray:
        score_min = float(artifact["train_score_min"])
        score_max = float(artifact["train_score_max"])
        denominator = max(score_max - score_min, 1e-8)
        return np.clip((raw_scores - score_min) / denominator, 0.0, 1.0)

