from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from sklearn.metrics import f1_score, precision_score, recall_score


@dataclass(frozen=True)
class EvaluationMetrics:
    precision: float
    recall: float
    f1_score: float


class Evaluator:
    def evaluate(self, documents: Sequence[dict]) -> EvaluationMetrics:
        y_true = [bool(document["is_anomaly"]) for document in documents]
        y_pred = [bool(document.get("predicted_anomaly", False)) for document in documents]

        return EvaluationMetrics(
            precision=float(precision_score(y_true, y_pred, zero_division=0)),
            recall=float(recall_score(y_true, y_pred, zero_division=0)),
            f1_score=float(f1_score(y_true, y_pred, zero_division=0)),
        )

