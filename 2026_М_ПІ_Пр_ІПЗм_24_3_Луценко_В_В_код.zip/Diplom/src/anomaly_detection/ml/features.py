from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Sequence

import numpy as np
from sklearn.preprocessing import StandardScaler

from anomaly_detection.domain.telemetry import METRIC_COLUMNS


FEATURE_COLUMNS = [
    *METRIC_COLUMNS,
    "delta_inputRowsPerSecond",
    "delta_processedRowsPerSecond",
    "delta_avgOffsetsBehindLatest",
    "delta_batchDuration",
    "delta_cpu_usage",
    "delta_memory_usage",
    "throughput_efficiency",
    "lag_ratio",
]


@dataclass
class TelemetryFeatureBuilder:
    scaler: StandardScaler = field(default_factory=StandardScaler)
    fitted: bool = False

    def fit_transform(self, documents: Sequence[dict]) -> np.ndarray:
        raw_features = self._build_raw_matrix(documents)
        transformed = self.scaler.fit_transform(raw_features)
        self.fitted = True
        return transformed

    def transform(self, documents: Sequence[dict]) -> np.ndarray:
        if not self.fitted:
            raise RuntimeError("TelemetryFeatureBuilder must be fitted before transform().")
        raw_features = self._build_raw_matrix(documents)
        return self.scaler.transform(raw_features)

    def _build_raw_matrix(self, documents: Sequence[dict]) -> np.ndarray:
        rows: List[np.ndarray] = []
        previous_metrics = None

        for document in documents:
            metrics = document["metrics"]
            rows.append(self._build_raw_features(metrics, previous_metrics))
            previous_metrics = metrics

        return np.vstack(rows)

    def _build_raw_features(self, metrics: dict, previous_metrics: dict | None) -> np.ndarray:
        values = np.array([float(metrics[name]) for name in METRIC_COLUMNS], dtype=float)

        if previous_metrics is None:
            deltas = np.zeros(len(METRIC_COLUMNS), dtype=float)
        else:
            previous_values = np.array(
                [float(previous_metrics[name]) for name in METRIC_COLUMNS],
                dtype=float,
            )
            deltas = values - previous_values

        input_rows = max(float(metrics["inputRowsPerSecond"]), 1e-8)
        throughput_efficiency = float(metrics["processedRowsPerSecond"]) / input_rows
        lag_ratio = float(metrics["avgOffsetsBehindLatest"]) / input_rows

        return np.concatenate(
            [
                values,
                deltas,
                np.array([throughput_efficiency, lag_ratio], dtype=float),
            ]
        )

