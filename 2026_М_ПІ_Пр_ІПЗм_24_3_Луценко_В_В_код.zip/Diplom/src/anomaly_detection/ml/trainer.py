from __future__ import annotations

from pathlib import Path

import joblib
import numpy as np
from sklearn.ensemble import IsolationForest

from anomaly_detection.domain.telemetry import TelemetryRepository
from anomaly_detection.ml.features import FEATURE_COLUMNS, TelemetryFeatureBuilder


class ModelTrainer:
    def __init__(
        self,
        repository: TelemetryRepository,
        model_path: str | Path = "artifacts/isolation_forest_model.joblib",
    ) -> None:
        self.repository = repository
        self.model_path = Path(model_path)

    def train(self) -> Path:
        normal_documents = self.repository.fetch_normal()
        if len(normal_documents) < 50:
            raise RuntimeError("Not enough normal records for training.")

        feature_builder = TelemetryFeatureBuilder()
        features = feature_builder.fit_transform(normal_documents)

        model = IsolationForest(
            n_estimators=100,
            contamination=0.01,
            random_state=42,
        )
        model.fit(features)

        train_raw_scores = -model.score_samples(features)
        artifact = {
            "model": model,
            "feature_builder": feature_builder,
            "feature_columns": FEATURE_COLUMNS,
            "train_score_min": float(np.min(train_raw_scores)),
            "train_score_max": float(np.max(train_raw_scores)),
        }

        self.model_path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(artifact, self.model_path)
        return self.model_path

