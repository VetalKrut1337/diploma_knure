from __future__ import annotations

import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from anomaly_detection.config import CliConfigParser


def main() -> None:
    config = CliConfigParser().parse()

    from anomaly_detection.container import ApplicationContainer

    pipeline = ApplicationContainer(config).build_pipeline()
    result = pipeline.run()

    print("Streaming anomaly detection pipeline finished")
    print(f"Records: {result.records_count}")
    print(f"Real anomalies: {result.real_anomalies}")
    print(f"Predicted anomalies: {result.predicted_anomalies}")
    print(f"MongoDB: {config.mongo.uri}{config.mongo.database}.{config.mongo.collection}")
    print(f"Threshold: {config.pipeline.anomaly_threshold:.2f}")
    print(f"Precision: {result.precision:.3f}")
    print(f"Recall: {result.recall:.3f}")
    print(f"F1-score: {result.f1_score:.3f}")
    print(f"Model saved to: {result.model_path}")
    print(f"Plot saved to: {result.plot_path}")


if __name__ == "__main__":
    main()
